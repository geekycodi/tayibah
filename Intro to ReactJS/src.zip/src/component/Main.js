import React ,{Component} from'react';
import './MainStyle.css';

class Main extends Component {

    state={
        name:'',
        password:''
    };

   getInputValue=(e)=>{
       this.setState({
           [e.target.type]:e.target.value,
       })
   } ;

    render() {

        return (


        <main>
             Main

            <p> {this.state.name} {this.state.password} </p>

        <button className="btn" onClick={this.props.countbtn}> Click me</button>


        </main>


        )

    }

}
export default Main;

