import React,{Component} from 'react';


class Footer extends Component{


    render(){

        return(

            <footer  className="demo">
                Footer
            </footer>
        )
    }



}

export default Footer;

