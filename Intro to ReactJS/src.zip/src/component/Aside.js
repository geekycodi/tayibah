import React ,{Component} from'react';


class Aside extends Component{

    state={
        name:"ttn"
    }



    render(){

       return(

           <aside  >


               Aside


               <button onClick={()=>{this.props.getData(this.state.name)}}>Click to send data</button>


           </aside>
       )
   }



}

export default Aside;