import React, { Component } from 'react';

import './App.css';


class App extends React.Component {

   constructor(props){

       super(props);

       this.state={
           count1:0,
           count2:0,
           count3:0,


       }

   };


    IncreaseCount1=(count1)=>{

        this.setState({count1:this.state.count1+=1});


    }


    DecreaseCount1=(count1)=>{

        this.state.count1-=1;
        this.setState({count1:this.state.count1});

    }








    IncreaseCount2=(count2)=>{

        this.setState({count2:this.state.count2+=1});


    }


    DecreaseCount2=(count2)=>{

        this.state.count2-=1;
        this.setState({count2:this.state.count2});

    }


    IncreaseCount3=(count3)=>{

        this.setState({count3:this.state.count3+=1});


    }


    DecreaseCount3=(count3)=>{

        this.state.count3-=1;
        this.setState({count3:this.state.count3});

    }




IncreaseAll=()=>{
    this.setState({count1:this.state.count1+1});
    this.setState({count2:this.state.count2+1});
    this.setState({count3:this.state.count3+1});
}



    DecreaseAll=()=>{
        this.setState({count1:this.state.count1-1});
        this.setState({count2:this.state.count2-1});
        this.setState({count3:this.state.count3-1});
    }



    render(){

      return (

             <div className="App">


             <Counter1 IncreaseCount1={this.IncreaseCount1} DecreaseCount1={this.DecreaseCount1}   showCount1={this.state.count1}    />

             <Counter2 IncreaseCount2={this.IncreaseCount2} DecreaseCount2={this.DecreaseCount2}   showCount2={this.state.count2} />
             <Counter3 IncreaseCount3={this.IncreaseCount3} DecreaseCount3={this.DecreaseCount3}   showCount3={this.state.count3} />

                 <button onClick ={this.IncreaseAll}>  Increase all</button>
                     <button onClick ={this.DecreaseAll}>  Decrease all</button>







             </div>
    );
  }
}



class Counter1 extends React.Component{


    render() {
    return (

            <div>

                Counter1

                <button onClick={this.props.IncreaseCount1} value="+">+</button>
                <button onClick={this.props.DecreaseCount1}  value="-">-</button>
                <span>{this.props.showCount1}</span>


            </div>
        );
    }

}



class Counter2 extends React.Component{


    render() {
        return (

            <div>
                Counter 2
                <button onClick={this.props.IncreaseCount2}  value="+">+</button>
                <button onClick={this.props.DecreaseCount2}  value="-">-</button>
                <span> {this.props.showCount2} </span>




            </div>
        );
    }



}

class Counter3 extends React.Component{

    render(){
        return (

            <div>

                Counter 3
                <button onClick={this.props.IncreaseCount3}  value="+">+</button>
                <button onClick={this.props.DecreaseCount3}  value="-">-</button>
                <span> {this.props.showCount3} </span>

            </div>
        );
    }



}



export default App;
